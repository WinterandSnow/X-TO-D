import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
import re

df = pd.read_excel('C:\\Users\\Administrator\\Desktop\\name to locality.xlsx', header=None, names=['fungus_name'])

driver = webdriver.Chrome()
driver.get('https://www.indexfungorum.org/Names/Names.asp')

valid_names = []
associated_texts = []

for _, row in df.iterrows():
    fungus_name = row['fungus_name']
    
    search_box = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.NAME, 'SearchTerm')))
    search_box.clear()
    search_box.send_keys(fungus_name)
    
    submit_button = driver.find_element(By.NAME, 'submit')
    submit_button.click()
    
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.TAG_NAME, 'body')))
    
    try:
        element = driver.find_element(By.XPATH, '/html/body/table/tbody/tr[2]/td/table/tbody/tr/td/a[1]')
        element.click()
        
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.TAG_NAME, 'body')))
        
        page_source = driver.page_source
        
        if 'Camellia sinensis' in page_source:
            valid_names.append(fungus_name)
            
            # 使用XPath获取Camellia sinensis后面的文本
            try:
                full_text = driver.find_element(By.XPATH, '/html/body/table/tbody/tr[2]/td/table/tbody/tr/td').text
                camellia_text = re.search(r'Camellia sinensis(.*)', full_text)
                if camellia_text:
                    associated_texts.append(camellia_text.group(1).strip())
                else:
                    associated_texts.append("Text after 'Camellia sinensis' not found")
            except:
                associated_texts.append("Text extraction failed")
        
    except:
        print(f"No result found for {fungus_name}")
    
    driver.back()

valid_df = pd.DataFrame({'fungus_name': valid_names, 'associated_text': associated_texts})
valid_df.to_excel('output.xlsx', index=False)

driver.quit()